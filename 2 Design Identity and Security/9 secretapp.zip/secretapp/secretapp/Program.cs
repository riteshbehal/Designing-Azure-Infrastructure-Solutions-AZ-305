﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;

string tenantId = "70c0f6d9-7f3b-4425-a6b6-09b47643ec58";
string clientId = "8b34a56b-84b1-4117-a852-86ec90b7a403";
string clientSecret = "EaM8Q~eoZZ5MQn6hEUtQ.vBJVf~G5pDYea-gbc9v";

// Given the application only the Get permission on the secret

string keyvaultUrl = "https://appvault55343.vault.azure.net/";
string secretName = "datapassword";

ClientSecretCredential clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);
SecretClient secretClient = new SecretClient(new Uri(keyvaultUrl), clientSecretCredential);

var secret = secretClient.GetSecret(secretName);

string dbpassword = secret.Value.Value;
Console.WriteLine(dbpassword);
