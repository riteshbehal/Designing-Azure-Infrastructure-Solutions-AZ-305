﻿using Azure.Identity;
using Azure.Storage.Blobs;

string blob_url = "https://appstore44343.blob.core.windows.net/scripts/commands.sql";
string local_blob = "C:\\tmp1\\commands.sql";


string tenantid = "70c0f6d9-7f3b-4425-a6b6-09b47643ec58";
string clientid = "8b34a56b-84b1-4117-a852-86ec90b7a403";
string clientsecret = "EaM8Q~eoZZ5MQn6hEUtQ.vBJVf~G5pDYea-gbc9v";

ClientSecretCredential _client_credential = new ClientSecretCredential(tenantid, clientid, clientsecret);

Uri blob_uri = new Uri(blob_url);

BlobClient _blob_client = new BlobClient(blob_uri, _client_credential);

_blob_client.DownloadTo(local_blob);

Console.WriteLine("Blob downloaded");
Console.ReadKey();